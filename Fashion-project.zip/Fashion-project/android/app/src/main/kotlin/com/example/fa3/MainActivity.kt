package com.example.fa3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
